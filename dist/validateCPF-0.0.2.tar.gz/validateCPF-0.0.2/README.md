# validate-CPF

English: Function to validade the inputed CPF. It can validade CPF's inputed as just numbers or
as xxx.xxx.xxx-xx. The function returns the CPF as a eleven digit interger number.
    
Portugues: Função para validar um CPF inputado. A função consegue validar CPF's inputados somente como números ou no formato xxx.xxx.xxx-xx. A função retorna o CPF como um numero inteiro de onze digitos.

```Python
from validateCPF import getCPF

x = getCPF("Digite seu CPF: ")

```